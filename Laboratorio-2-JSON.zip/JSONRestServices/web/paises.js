$(document).ready(function () {
    var table = '<table class="table table-hover">'
            + '<thead>'
            + '<tr>'
            + '<th>Code</th>'
            + '<th>Name</th>'
            + '<th>Continent</th>'
            + '<th>Region</th>'
            + '<th>Population</th>'
            + '<th>Capital</th>'
            + '</tr>'
            + '</thead>'
            + '<tbody>';
    $("#show-data").click(function () {
        $.get("http://localhost:8080/JSONRestServices/ServletService", function (paises) {
            $.each(paises, function (k, v) {
                table += '<tr>'
                        + '<td>' + v.code + '</td>'
                        + '<td>' + v.name + '</td>'
                        + '<td>' + v.continent + '</td>'
                        + '<td>' + v.region + '</td>'
                        + '<td>' + v.population + '</td>'
                        + '<td>' + v.capital + '</td>'
                        + '</tr>';
            });
            table += '</tbody>'
                    +'</table>';
            $("#table-data").html(table);
        });
    });
    $("#create").submit(function () {
        var json = {
            code: $("#code").val(),
            name: $("#code").val(),
            continent: $("#continent").val(),
            region: $("#region").val(),
            population: $("#population").val(),
            capital: $("#capital").val()
        };
        $.ajax(
                {
                    url: "http://localhost:8080/JSONRestServices/webresources/pais",
                    type: 'POST',
                    data: JSON.stringify(json),
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json',
                    async: false,
                    success: function () {
                        alert('Country Created');
                    }
                }
        );
    });
});